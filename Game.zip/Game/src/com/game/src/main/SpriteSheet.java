package com.game.src.main;

import java.awt.image.BufferedImage;    //gets spritr from sprite sheet

public class SpriteSheet {

    public SpriteSheet(BufferedImage image) {
    }

    public BufferedImage grabImage(int col, int row, int width, int height, BufferedImage image) {

        BufferedImage img = image.getSubimage((col * width) - width, (row * height) - height, width, height);
        return img;

    }
}
