package com.game.src.main;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.*;

public class firejet {                                          //same as demon and Tenticle. Handles rendering of enemys.

    ArrayList<cordinates> cords = new ArrayList<cordinates>();

    private BufferedImage sprite;

    Game game;

    SpriteSheet ss;

    public firejet(Game game) {     //Gets sprites

        this.game = game;
        this.ss = new SpriteSheet(game.getSpriteSheet());
        sprite = ss.grabImage(5, 1, 64, 64, game.getSpriteSheet());

    }

    public void tick() {// runs 60 x a second

        for (int i = 0; i < cords.size(); i++) {
            cords.get(i).editX(3);
        }

    }

    public void render(Graphics g) {    //renders sprites
        for (int i = 0; i < cords.size(); i++) {

            g.drawImage(sprite, (int) cords.get(i).getX(), (int) cords.get(i).getY(), null);
            if (cords.get(i).getX() <= -64) {
                cords.remove(i);
            }
        }
    }

    public void spawnNew() {
        cords.add(new cordinates(1024, 185, "firejet"));        //spawns new object
    }

    public ArrayList<cordinates> getCords() {
        return cords;
    }
}