package com.game.src.main;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.*;

public class Tenticle {//same as firejet

    ArrayList<cordinates> cords = new ArrayList<cordinates>();

    private BufferedImage sprite;

    Game game;

    SpriteSheet ss;

    public Tenticle(Game game) {

        this.game = game;
        this.ss = new SpriteSheet(game.getSpriteSheet());
        sprite = ss.grabImage(7, 1, 64, 64, game.getSpriteSheet());

    }

    public void tick() {

        for (int i = 0; i < cords.size(); i++) {
            cords.get(i).editX(3);
        }

    }

    public void render(Graphics g) {
        for (int i = 0; i < cords.size(); i++) {

            g.drawImage(sprite, (int) cords.get(i).getX(), (int) cords.get(i).getY(), null);
            if (cords.get(i).getX() <= -64) {
                cords.remove(i);
            }
        }
    }

    public void spawnNew() {
        cords.add(new cordinates(1024, 185, "tenticle"));
    }

    public ArrayList<cordinates> getCords() {
        return cords;
    }
}