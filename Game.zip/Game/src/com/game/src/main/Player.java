package com.game.src.main;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

public class Player {

    private int animSpeedMod = 10;
    private int animFrameCount = 0;
    private int ticks = 60;
    private int CFrame = 1;
    private int counter = 0;

    private double x;
    private double y;
    private double g = 9.8;
    private double yMom = 0.0;
    private double gLev = 185.0;

    Graphics gr;

    private Rectangle colbox = new Rectangle((int) x - 25, (int) y, 13, 64);    //creates hitbox

    SpriteSheet ss;

    //	private boolean crouched = false;
    private boolean jumped = false;
    private boolean t2a = false;
    private boolean t2b = false;
    private boolean t2c = false;

    private BufferedImage player;

    public Player(double x, double y, Game game) {//constructor

        this.x = x;
        this.y = y;

        this.ss = new SpriteSheet(game.getSpriteSheet());
        player = ss.grabImage(1, 1, 64, 64, game.getSpriteSheet());

    }

    public void tick(Game game) {//tick function

        y = y - yMom;
        yMom = yMom - g / 60;
        if (y > gLev) {
            yMom = 0;
            y = gLev;
        }

        animFrameCount++;

        if (animFrameCount > ticks / animSpeedMod) { //animation
            animFrameCount = 0;
            CFrame++;
            if (CFrame > 8) CFrame = 1;
        }
        if (y >= gLev) jumped = false;
        try {
            if (jumped) {
                player = ss.grabImage(5, 2, 64, 64, game.getSpriteSheet());
                CFrame = 3;
            } else if (CFrame <= 4) {
                player = ss.grabImage(CFrame, 1, 64, 64, game.getSpriteSheet());
            } else {
                player = ss.grabImage(CFrame - 4, 2, 64, 64, game.getSpriteSheet());
            }
        } catch (NullPointerException e) {
            e.printStackTrace();
        }

    }


    public void render(Graphics g) {//rendering
        g.drawImage(player, (int) x, (int) y, null);
        gr = g;
    }


    public void Jump() {//jump method
        if (y == gLev) {
            System.out.println("Jump");
            jumped = true;
            yMom = 5.0;
        }
    }

    public void CroutchS() {

//		crouched = true;

    }

    public void CroutchE() {

//		crouched = false;

    }

    public void setYMom(double YMom) {
        this.yMom = YMom;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public boolean getJumped() {
        return jumped;
    }

    public Rectangle getPlayerbox() {//getters
        if (jumped) {
            colbox.setSize(31, 30);
            colbox.setLocation((int) x, (int) y);
            return colbox;
        } else {
            colbox.setSize(13, 64);
            colbox.setLocation((int) x + 25, (int) y);
            return colbox;
        }
    }

    public void tick2(Game game) {//2. game loop

        if (counter == 30 && t2a == false) {
            player = ss.grabImage(6, 2, 64, 64, game.getSpriteSheet());
            counter = 0;
            t2a = true;
        }

        if (counter == 75 && t2b == false) {
            player = ss.grabImage(7, 2, 64, 64, game.getSpriteSheet());
            counter = 0;
            t2b = true;
        }

        if (counter == 60 && t2c == false && t2b == true) {
            player = ss.grabImage(8, 2, 64, 64, game.getSpriteSheet());
            counter = 0;
            t2c = true;
        }

        if (counter == 20 && t2c == true) {
            //paint(gr);
        } else {
            counter++;

        }
    }

    //public void paint(Graphics g) {

    //    g.drawString("", 10, 10);

    //}

}