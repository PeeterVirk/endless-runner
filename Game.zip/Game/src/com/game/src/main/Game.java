package com.game.src.main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class Game extends Canvas implements Runnable {

    private static final long serialVersionUID = 1L; //initialising some values/classes

    public static final int WIDTH = 1024;
    public static final int HEIGHT = 256;
    public static final int SCALE = 1;

    private int jumpCounter = 1;
    private int nextJump = 150;
    private int nextType;

    public final String TITLE = "Endless Runner";

    private boolean running = false;

    private Thread thread;

    private BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
    private BufferedImage spriteSheet = null;
//    private BufferedImage Background = null;
//    private BufferedImage Foreground = null;

    private Random rand;
    private Player p;
    private firejet FireJ;
    private demon Demon;
    private Tenticle Tenticle;
    private handleGrounds bg;
    private handleGrounds fg;

    private ArrayList<cordinates> GlobalBlockersCordinates = new ArrayList<cordinates>();

    public void init() { // annab väärtused ja alustab klassid
        BIL loader = new BIL();

        addKeyListener(new KeyInput(this));

        try {       //laeb pildid
            spriteSheet = loader.loadImage("/SpriteMap.png");
//    		Background = loader.loadImage("/bg.png");
        } catch (IOException e) {
            e.printStackTrace();
        }

        rand = new Random();


        p = new Player(30, 180, this);      //alustab versioonid objektidest
        FireJ = new firejet(this);
        Demon = new demon(this);
        Tenticle = new Tenticle(this);
//   	bg = new handleGrounds (this, Background, HEIGHT, HEIGHT, 1);
//   	fg = new handleGrounds (this, image, jumpCounter, HEIGHT, 3);

    }

    private synchronized void start() { //runs when program starts
        if (running) return;            //alustab threadid
        running = true;
        thread = new Thread(this);
        thread.start();
    }

    private synchronized void stop() {    //runs when program stoped
        if (!running)
            return;

        running = false;
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.exit(1);

    }

    public void run() {     //handels framerate
        init();
        long lastTime = System.nanoTime();
        final double ammountOfTicks = 60.0;
        double ns = 1000000000 / ammountOfTicks;
        double delta = 0;
        int updates = 0;
        int frames = 0;
        long timer = System.currentTimeMillis();


        while (running) {           //game loop 1
            long now = System.nanoTime();
            delta += (now - lastTime) / ns;
            lastTime = now;
            if (delta >= 1) {
                tick();         //calls ticks
                updates++;
                delta--;
                //System.out.println(delta);
            }
            render();
            frames++;

            if (System.currentTimeMillis() - timer > 1000) {
                timer += 1000;
                System.out.println(updates + " Ticks, Fps " + frames);
                updates = 0;
                frames = 0;
            }
        }
        boolean running2 = true;        //game loop 2
        System.out.println("break");    //responcible for death animation
        while (running2) {
            long now = System.nanoTime();
            delta += (now - lastTime) / ns;
            lastTime = now;
            if (delta >= 1) {
                tick2();
                updates++;
                delta--;
                //System.out.println(delta);
            }
            render();
            frames++;

            if (System.currentTimeMillis() - timer > 1000) {
                timer += 1000;
                System.out.println(updates + " Ticks, Fps " + frames);
                updates = 0;
                frames = 0;
            }
        }
        stop(); //calls stop
    }

    private void tick2() {      //game loop 2

        p.tick2(this);

    }

    private void tick() {       //game loop 1
        // runs 60x second
        if (jumpCounter >= nextJump) {
            nextJump = rand.nextInt((125 - 50) + 1) + 50;
            jumpCounter = 0;
            nextType = rand.nextInt(3);

            if (nextType == 0) {
                System.out.println("Fire");
                addColBox(1024, 185, "colfireJ");
                FireJ.spawnNew();
            } else if (nextType == 1) {
                System.out.println("Demon");
                addColBox(1024, 185, "coldemon");
                Demon.spawnNew();
            } else if (nextType == 2) {
                System.out.println("Tenticle");
                addColBox(1024, 185, "coltenticle");
                Tenticle.spawnNew();
            }
        }
        jumpCounter++;


        p.tick(this);       //calls tick functions in classes
        FireJ.tick();
        Demon.tick();
        Tenticle.tick();
//    	bg.tick();
        //fg.tick():

        for (int i = 0; i < GlobalBlockersCordinates.size(); i++) {
            GlobalBlockersCordinates.get(i).editX(3);
            GlobalBlockersCordinates.get(i).movebox((int) GlobalBlockersCordinates.get(i).getX(), (int) GlobalBlockersCordinates.get(i).getY());
            //System.out.println(GlobalBlockersCordinates.get(i));
            if (p.getPlayerbox().getBounds().intersects(GlobalBlockersCordinates.get(i).getbox().getBounds())) {

                die();
            }
            if (GlobalBlockersCordinates.get(i).getX() < -100) GlobalBlockersCordinates.remove(i);
        }

    }

    private void render() { //renders things

        BufferStrategy bs = this.getBufferStrategy();

        if (bs == null) {
            createBufferStrategy(2);
            return;
        }

        Graphics g = bs.getDrawGraphics();
        //drawing area

        g.drawImage(image, 0, 0, getWidth(), getHeight(), this);       //clears screen
//    	bg.render(g);  //calls render functions
        //fg.render(g);
        FireJ.render(g);
        Demon.render(g);
        Tenticle.render(g);
        p.render(g);

        //drawing area end
        g.dispose();
        bs.show();

    }

    public void keyPressed(KeyEvent e) {        //key presses

        if (e.getKeyCode() == KeyEvent.VK_SPACE) {

            p.Jump();

        }

    }

    public void keyReleased(KeyEvent e) {       //key released

    }

    public void die() {     //kills character
        System.out.println("dye");
        running = false;
    }

    public static void main(String[] args) {        //main function
        Game game = new Game();

        game.setPreferredSize(new Dimension(WIDTH * SCALE, HEIGHT * SCALE));
        game.setMaximumSize(new Dimension(WIDTH * SCALE, HEIGHT * SCALE));
        game.setMinimumSize(new Dimension(WIDTH * SCALE, HEIGHT * SCALE));

        JFrame frame = new JFrame(game.TITLE);
        frame.add(game);
        frame.setFocusable(true);
        frame.setFocusableWindowState(true);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setAlwaysOnTop(true);
        game.start();
    }

    public BufferedImage getSpriteSheet() {     //getter
        return spriteSheet;
    }

    public void addColBox(int x, int y, String type) {
        GlobalBlockersCordinates.add(new cordinates(x, y, type));
    }

}