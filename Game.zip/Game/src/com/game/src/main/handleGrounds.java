package com.game.src.main;          //not in use by now

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Random;

public class handleGrounds {

    ArrayList<cordinates> bgcords = new ArrayList<cordinates>();

    Game game;

    private SpriteSheet ss;

    private BufferedImage sprite;
    private BufferedImage image;

    private int col;
    private int row;
    private int w;
    private int h;

    private int n;
    private int counter;

    private Random rand;


    public handleGrounds(Game game, BufferedImage image, int w, int h, int n) {

        this.game = game;
        this.ss = new SpriteSheet(game.getSpriteSheet());
        sprite = ss.grabImage(1, 1, w, h, game.getSpriteSheet());

        this.n = n;

        rand = new Random();

        spawnNew(1025, 0);
        spawnNew(1025, 256);
        spawnNew(1025, 512);
        spawnNew(1025, 768);

        counter = w;
    }

    public BufferedImage grabImage(int col, int row, int width, int height) {

        BufferedImage img = image.getSubimage((col * width) - width, (row * height) - height, width, height);
        return img;

    }

    public void tick() {

        this.counter += 1;

        col = rand.nextInt(4);

        for (int i = 0; i < bgcords.size(); i++) {
            bgcords.get(i).editX(n);
        }

        if (counter >= w) {
            counter = 0;
            spawnNew(1025, 0);
            System.out.println(w);
        }

    }

    public void render(Graphics g) {


        for (int i = 0; i < bgcords.size(); i++) {

            g.drawImage(sprite, (int) bgcords.get(i).getX(), (int) bgcords.get(i).getY(), null);
            if (bgcords.get(i).getX() <= -64) {
                bgcords.remove(i);
            }
        }

    }

    private void spawnNew(int x, int y) {
        bgcords.add(new cordinates(x, y, "bg"));
    }
}
