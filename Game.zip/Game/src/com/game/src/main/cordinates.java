package com.game.src.main;

import java.awt.Rectangle;      //handles mass cordinate storage

public class cordinates {

    private double x;
    private double y;
    private String type;
    private Rectangle colbox;

    public cordinates(double x, double y, String type) {//handles storage

        this.x = x;
        this.y = y;
        this.setType(type);
        if (type == "colfireJ") {
            colbox = new Rectangle((int) x, (int) y - 25, 22, 39);
        } else if (type == "coldemon") {
            colbox = new Rectangle((int) x, (int) y, 64, 64);
        } else if (type == "coltenticle") {
            colbox = new Rectangle((int) x, (int) y - 25, 30, 15);
        }
    }

    public double getX() {
        return x;
    }//getters/setters

    public double getY() {
        return y;
    }

    public void editX(int i) {
        x = x - i;
    }

    public void editY(int i) {
        y = y - i;
    }

    public void movebox(int x, int y) {
        colbox.setLocation(x, y);
    }

    public Rectangle getbox() {
        return colbox;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

}
